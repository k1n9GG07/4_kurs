const jwt = require('jsonwebtoken');
require('dotenv').config();

class JWTManager {
    constructor() {
        this.secret = process.env.JWT_SECRET;
        this.expiresIn = '24h';
    }

    generateToken(payload) {
        return jwt.sign(payload, this.secret, { expiresIn: this.expiresIn });
    }

    verifyToken(token) {
        try {
            return jwt.verify(token, this.secret);
        } catch (error) {
            return null;
        }
    }
}

module.exports = new JWTManager();