const User = require('../models/User');
const UserValidator = require('../validators/UserValidator');
const jwtManager = require('../config/jwt');

class AuthController {
    static async register(req, res) {
        try {
            const { login, password, full_name, phone, email } = req.body;

            const validation = UserValidator.validateRegistration(req.body);
            if (!validation.valid) {
                return res.status(400).json({ errors: validation.errors });
            }

            const existingUser = await User.findByLogin(login);
            if (existingUser) {
                return res.status(400).json({ errors: ['Пользователь с таким логином уже существует'] });
            }

            const existingEmail = await User.findByEmail(email);
            if (existingEmail) {
                return res.status(400).json({ errors: ['Пользователь с таким email уже существует'] });
            }

            const user = new User({ login, password, full_name, phone, email });
            await user.save();

            res.status(201).json({ 
                message: 'Пользователь успешно зарегистрирован',
                userId: user.id
            });
        } catch (error) {
            console.error('Registration error:', error);
            res.status(500).json({ error: 'Ошибка сервера при регистрации' });
        }
    }

    static async login(req, res) {
        try {
            const { login, password } = req.body;

            if (!login || !password) {
                return res.status(400).json({ error: 'Введите логин и пароль' });
            }

            const user = await User.findByLogin(login);
            if (!user) {
                return res.status(401).json({ error: 'Неверный логин или пароль' });
            }

            const isValidPassword = await User.verifyPassword(password, user.password_hash);
            if (!isValidPassword) {
                return res.status(401).json({ error: 'Неверный логин или пароль' });
            }

            const token = jwtManager.generateToken({
                id: user.id,
                login: user.login,
                role: user.role
            });

            res.json({
                message: 'Авторизация успешна',
                token: token,
                user: {
                    id: user.id,
                    login: user.login,
                    full_name: user.full_name,
                    role: user.role
                }
            });
        } catch (error) {
            console.error('Login error:', error);
            res.status(500).json({ error: 'Ошибка сервера при авторизации' });
        }
    }

    static async getProfile(req, res) {
        try {
            const user = await User.findById(req.user.id);
            if (!user) {
                return res.status(404).json({ error: 'Пользователь не найден' });
            }
            res.json(user);
        } catch (error) {
            console.error('Get profile error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}

module.exports = AuthController;