const Booking = require('../models/Booking');
const Facility = require('../models/Facility');

class BookingController {
    static async create(req, res) {
        try {
            const { facility_name, booking_date, payment_method } = req.body;

            if (!facility_name || !booking_date || !payment_method) {
                return res.status(400).json({ error: 'Заполните все поля' });
            }

            const facilities = await Facility.searchByName(facility_name);
            if (facilities.length === 0) {
                return res.status(404).json({ error: 'Спортивная площадка не найдена' });
            }

            const facility = facilities[0];

            const booking = new Booking({
                user_id: req.user.id,
                facility_id: facility.id,
                booking_date: booking_date,
                payment_method: payment_method
            });

            await booking.save();

            res.status(201).json({
                message: 'Заявка успешно создана',
                booking: booking
            });
        } catch (error) {
            console.error('Create booking error:', error);
            res.status(500).json({ error: 'Ошибка сервера при создании заявки' });
        }
    }

    static async getUserBookings(req, res) {
        try {
            const bookings = await Booking.findByUserId(req.user.id);
            res.json(bookings);
        } catch (error) {
            console.error('Get user bookings error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async getAllBookings(req, res) {
        try {
            const bookings = await Booking.findAll();
            res.json(bookings);
        } catch (error) {
            console.error('Get all bookings error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async updateStatus(req, res) {
        try {
            const { id } = req.params;
            const { status } = req.body;

            if (!['approved', 'rejected'].includes(status)) {
                return res.status(400).json({ error: 'Недопустимый статус' });
            }

            await Booking.updateStatus(id, status);
            res.json({ message: 'Статус заявки обновлен' });
        } catch (error) {
            console.error('Update status error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}

module.exports = BookingController;