const Facility = require('../models/Facility');

class FacilityController {
    static async getAll(req, res) {
        try {
            const facilities = await Facility.findAll();
            res.json(facilities);
        } catch (error) {
            console.error('Get facilities error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async search(req, res) {
        try {
            const { name } = req.query;
            if (!name) {
                return res.json([]);
            }
            const facilities = await Facility.searchByName(name);
            res.json(facilities);
        } catch (error) {
            console.error('Search facilities error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}

module.exports = FacilityController;