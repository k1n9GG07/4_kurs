const Review = require('../models/Review');
const Booking = require('../models/Booking');

class ReviewController {
    static async create(req, res) {
        try {
            const { booking_id, rating, comment } = req.body;

            if (!booking_id || !rating) {
                return res.status(400).json({ error: 'Укажите заявку и рейтинг' });
            }

            const booking = await Booking.findById(booking_id);
            if (!booking || booking.user_id !== req.user.id) {
                return res.status(403).json({ error: 'Нет доступа к этой заявке' });
            }

            if (booking.status !== 'approved') {
                return res.status(400).json({ error: 'Можно оставить отзыв только об одобренной заявке' });
            }

            const review = new Review({
                booking_id: booking_id,
                user_id: req.user.id,
                rating: rating,
                comment: comment || ''
            });

            await review.save();

            res.status(201).json({
                message: 'Отзыв успешно добавлен',
                review: review
            });
        } catch (error) {
            console.error('Create review error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async getUserReviews(req, res) {
        try {
            const reviews = await Review.findByUserId(req.user.id);
            res.json(reviews);
        } catch (error) {
            console.error('Get user reviews error:', error);
            res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}

module.exports = ReviewController;