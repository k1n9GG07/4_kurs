// fix-admin.js
require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function fixAdminPassword() {
    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });

    const newPassword = 'admin123';
    const hash = await bcrypt.hash(newPassword, 10);
    
    console.log('Генерируем новый хеш для admin123...');
    console.log('Хеш:', hash);

    await connection.execute(
        'UPDATE users SET password_hash = ? WHERE login = ?', 
        [hash, 'admin']
    );

    console.log('[OK] Пароль администратора успешно обновлен!');
    console.log('Теперь можно войти с паролем: admin123');
    
    await connection.end();
}

fixAdminPassword().catch(console.error);