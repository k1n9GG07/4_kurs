const jwtManager = require('../config/jwt');

class AuthMiddleware {
    static authenticate(req, res, next) {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'Требуется авторизация' });
        }

        const token = authHeader.substring(7);
        const decoded = jwtManager.verifyToken(token);

        if (!decoded) {
            return res.status(401).json({ error: 'Недействительный токен' });
        }

        req.user = decoded;
        next();
    }

    static authorizeAdmin(req, res, next) {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ error: 'Доступ запрещен. Требуются права администратора' });
        }
        next();
    }
}

module.exports = AuthMiddleware;