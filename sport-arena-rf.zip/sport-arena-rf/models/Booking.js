const db = require('../config/database');

class Booking {
    constructor(data) {
        this.id = data.id || null;
        this.user_id = data.user_id;
        this.facility_id = data.facility_id;
        this.booking_date = data.booking_date;
        this.payment_method = data.payment_method;
        this.status = data.status || 'pending';
    }

    static async findByUserId(userId) {
        const sql = `SELECT b.*, f.name as facility_name, f.type as facility_type, f.image_url as facility_image
                     FROM bookings b 
                     JOIN facilities f ON b.facility_id = f.id 
                     WHERE b.user_id = ? 
                     ORDER BY b.created_at DESC`;
        return await db.query(sql, [userId]);
    }

    static async findAll() {
        const sql = `SELECT b.*, u.full_name as user_name, u.login as user_login, 
                     f.name as facility_name, f.type as facility_type, f.image_url as facility_image
                     FROM bookings b 
                     JOIN users u ON b.user_id = u.id 
                     JOIN facilities f ON b.facility_id = f.id 
                     ORDER BY b.created_at DESC`;
        return await db.query(sql);
    }

    static async findById(id) {
        const sql = `SELECT b.*, f.name as facility_name, f.image_url as facility_image, u.full_name as user_name 
                     FROM bookings b 
                     JOIN facilities f ON b.facility_id = f.id 
                     JOIN users u ON b.user_id = u.id 
                     WHERE b.id = ?`;
        const results = await db.query(sql, [id]);
        return results[0] || null;
    }

    async save() {
        const sql = `INSERT INTO bookings (user_id, facility_id, booking_date, payment_method, status) 
                     VALUES (?, ?, ?, ?, ?)`;
        const params = [this.user_id, this.facility_id, this.booking_date, this.payment_method, this.status];
        const result = await db.query(sql, params);
        this.id = result.insertId;
        return this;
    }

    static async updateStatus(id, status) {
        const sql = 'UPDATE bookings SET status = ? WHERE id = ?';
        await db.query(sql, [status, id]);
        return true;
    }
}

module.exports = Booking;