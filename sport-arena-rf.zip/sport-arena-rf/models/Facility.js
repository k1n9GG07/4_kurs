const db = require('../config/database');

class Facility {
    constructor(data) {
        this.id = data.id || null;
        this.name = data.name;
        this.type = data.type;
        this.description = data.description;
    }

    static async findAll() {
        const sql = 'SELECT * FROM facilities WHERE is_active = TRUE ORDER BY name';
        return await db.query(sql);
    }

    static async findById(id) {
        const sql = 'SELECT * FROM facilities WHERE id = ?';
        const results = await db.query(sql, [id]);
        return results[0] || null;
    }

    static async searchByName(name) {
        const sql = 'SELECT * FROM facilities WHERE name LIKE ? AND is_active = TRUE';
        return await db.query(sql, [`%${name}%`]);
    }
}

module.exports = Facility;