const db = require('../config/database');

class Review {
    constructor(data) {
        this.id = data.id || null;
        this.booking_id = data.booking_id;
        this.user_id = data.user_id;
        this.rating = data.rating;
        this.comment = data.comment;
    }

    static async findByBookingId(bookingId) {
        const sql = 'SELECT * FROM reviews WHERE booking_id = ?';
        return await db.query(sql, [bookingId]);
    }

    static async findByUserId(userId) {
        const sql = `SELECT r.*, b.booking_date, f.name as facility_name, f.image_url as facility_image
                     FROM reviews r 
                     JOIN bookings b ON r.booking_id = b.id 
                     JOIN facilities f ON b.facility_id = f.id 
                     WHERE r.user_id = ? 
                     ORDER BY r.created_at DESC`;
        return await db.query(sql, [userId]);
    }

    async save() {
        const sql = `INSERT INTO reviews (booking_id, user_id, rating, comment) 
                     VALUES (?, ?, ?, ?)`;
        const params = [this.booking_id, this.user_id, this.rating, this.comment];
        const result = await db.query(sql, params);
        this.id = result.insertId;
        return this;
    }
}

module.exports = Review;