const bcrypt = require('bcryptjs');
const db = require('../config/database');

class User {
    constructor(data) {
        this.id = data.id || null;
        this.login = data.login;
        this.password = data.password;
        this.full_name = data.full_name;
        this.phone = data.phone;
        this.email = data.email;
        this.role = data.role || 'user';
    }

    static async findByLogin(login) {
        const sql = 'SELECT * FROM users WHERE login = ?';
        const results = await db.query(sql, [login]);
        return results[0] || null;
    }

    static async findByEmail(email) {
        const sql = 'SELECT * FROM users WHERE email = ?';
        const results = await db.query(sql, [email]);
        return results[0] || null;
    }

    static async findById(id) {
        const sql = 'SELECT id, login, full_name, phone, email, role, created_at FROM users WHERE id = ?';
        const results = await db.query(sql, [id]);
        return results[0] || null;
    }

    async save() {
        const salt = await bcrypt.genSalt(10);
        const password_hash = await bcrypt.hash(this.password, salt);
        
        const sql = `INSERT INTO users (login, password_hash, full_name, phone, email, role) 
                     VALUES (?, ?, ?, ?, ?, ?)`;
        const params = [this.login, password_hash, this.full_name, this.phone, this.email, this.role];
        
        const result = await db.query(sql, params);
        this.id = result.insertId;
        return this;
    }

    static async verifyPassword(plainPassword, hashedPassword) {
        return await bcrypt.compare(plainPassword, hashedPassword);
    }
}

module.exports = User;