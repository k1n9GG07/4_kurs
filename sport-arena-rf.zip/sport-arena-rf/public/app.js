// API Configuration
const API_URL = '/api';

// State Management
const state = {
    token: localStorage.getItem('token'),
    user: JSON.parse(localStorage.getItem('user') || 'null'),
    currentPage: 'bookings',
    selectedBookingId: null
};

// Utility Functions
class Utils {
    static async apiRequest(endpoint, options = {}) {
        const url = `${API_URL}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        if (state.token) {
            config.headers['Authorization'] = `Bearer ${state.token}`;
        }

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || data.errors?.join(', ') || 'Ошибка запроса');
            }

            return data;
        } catch (error) {
            throw error;
        }
    }

    static showError(elementId, message) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = message;
        }
    }

    static clearErrors() {
        document.querySelectorAll('.error-message').forEach(el => {
            el.textContent = '';
        });
    }

    static formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    static getStatusText(status) {
        const statuses = {
            pending: 'На рассмотрении',
            approved: 'Одобрена',
            rejected: 'Отклонена'
        };
        return statuses[status] || status;
    }

    static getPaymentText(method) {
        const methods = {
            onsite: 'При посещении',
            sbp: 'СБП'
        };
        return methods[method] || method;
    }

    static getPaymentIcon(method) {
        return method === 'onsite' ? 'fa-money-bill-1-wave' : 'fa-building-columns';
    }

    static renderStars(rating) {
        let html = '<div class="star-rating" aria-label="Рейтинг">';
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                html += '<i class="fa-solid fa-star star-filled"></i>';
            } else {
                html += '<i class="fa-regular fa-star star-empty"></i>';
            }
        }
        html += '</div>';
        return html;
    }

    static renderImage(url, alt, className = '', addFallback = true) {
        const fallbackUrl = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="100%25" height="100%25" fill="%23E5E5EA"/><path d="M200 130 L200 170 M180 150 L220 150" stroke="%238E8E93" stroke-width="4" stroke-linecap="round" fill="none"/><circle cx="200" cy="150" r="45" fill="none" stroke="%238E8E93" stroke-width="4"/></svg>';
        const imgUrl = url || fallbackUrl;
        const imgClass = className ? `${className} img-skeleton` : 'img-skeleton';
        const onError = addFallback ? `onerror="this.onerror=null;this.src='${fallbackUrl}';"` : '';
        return `<img src="${imgUrl}" alt="${alt || ''}" class="${imgClass}" loading="lazy" ${onError}>`;
    }
}

// Validation
class Validator {
    static login(login) {
        return /^[a-zA-Z0-9]{6,}$/.test(login);
    }

    static password(password) {
        return password.length >= 8;
    }

    static fullName(name) {
        return /^[а-яА-ЯёЁ\s]+$/.test(name);
    }

    static phone(phone) {
        return /^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/.test(phone);
    }

    static email(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
}

// Auth Module
class Auth {
    static async login(login, password) {
        Utils.clearErrors();
        
        if (!login) {
            Utils.showError('login-error', 'Введите логин');
            return;
        }
        if (!password) {
            Utils.showError('password-error', 'Введите пароль');
            return;
        }

        try {
            const data = await Utils.apiRequest('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ login, password })
            });

            state.token = data.token;
            state.user = data.user;
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));

            App.showAppScreen();
        } catch (error) {
            Utils.showError('login-error', error.message);
        }
    }

    static async register(userData) {
        Utils.clearErrors();

        if (!Validator.login(userData.login)) {
            Utils.showError('reg-login-error', 'Логин: латиница и цифры, мин. 6 символов');
            return;
        }
        if (!Validator.password(userData.password)) {
            Utils.showError('reg-password-error', 'Пароль: минимум 8 символов');
            return;
        }
        if (!Validator.fullName(userData.full_name)) {
            Utils.showError('reg-fullname-error', 'ФИО: только кириллица и пробелы');
            return;
        }
        if (!Validator.phone(userData.phone)) {
            Utils.showError('reg-phone-error', 'Формат: 8(XXX)XXX-XX-XX');
            return;
        }
        if (!Validator.email(userData.email)) {
            Utils.showError('reg-email-error', 'Некорректный email');
            return;
        }

        try {
            await Utils.apiRequest('/auth/register', {
                method: 'POST',
                body: JSON.stringify(userData)
            });

            alert('Регистрация успешна! Теперь вы можете войти.');
            document.getElementById('show-login').click();
        } catch (error) {
            if (error.message.includes('логином')) {
                Utils.showError('reg-login-error', error.message);
            } else if (error.message.includes('email')) {
                Utils.showError('reg-email-error', error.message);
            } else {
                alert(error.message);
            }
        }
    }

    static logout() {
        state.token = null;
        state.user = null;
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        App.showAuthScreen();
    }
}

// Bookings Module
class Bookings {
    static async loadUserBookings() {
        try {
            const bookings = await Utils.apiRequest('/bookings/my');
            this.renderBookings(bookings, 'bookings-list');
        } catch (error) {
            console.error('Error loading bookings:', error);
        }
    }

    static async createBooking(facilityName, bookingDate, paymentMethod) {
        try {
            await Utils.apiRequest('/bookings', {
                method: 'POST',
                body: JSON.stringify({
                    facility_name: facilityName,
                    booking_date: bookingDate,
                    payment_method: paymentMethod
                })
            });

            alert('Заявка успешно создана!');
            document.getElementById('booking-form').reset();
            this.loadUserBookings();
            App.navigateTo('bookings');
        } catch (error) {
            alert(error.message);
        }
    }

    static renderBookings(bookings, containerId) {
        const container = document.getElementById(containerId);
        
        if (bookings.length === 0) {
            container.innerHTML = `
                <div class="card empty-state">
                    <div class="empty-icon"><i class="fa-regular fa-calendar-xmark"></i></div>
                    <p>Заявок пока нет</p>
                    <span>Создайте свою первую заявку на тренировку</span>
                </div>`;
            return;
        }

        container.innerHTML = bookings.map(booking => `
            <div class="card booking-card">
                <div class="booking-image">
                    ${Utils.renderImage(booking.facility_image, booking.facility_name)}
                    <span class="status-badge status-${booking.status}">
                        <i class="fa-solid ${booking.status === 'approved' ? 'fa-circle-check' : booking.status === 'rejected' ? 'fa-circle-xmark' : 'fa-clock'}"></i>
                        ${Utils.getStatusText(booking.status)}
                    </span>
                </div>
                <div class="booking-content">
                    <div class="booking-header">
                        <div class="booking-title-block">
                            <div class="card-title">${booking.facility_name}</div>
                            <div class="card-subtitle">
                                <i class="fa-solid fa-layer-group"></i> ${booking.facility_type}
                            </div>
                        </div>
                    </div>
                    <div class="card-info">
                        <div class="info-item">
                            <span class="info-label"><i class="fa-regular fa-calendar"></i> Дата</span>
                            <span class="info-value">${Utils.formatDate(booking.booking_date)}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label"><i class="fa-solid ${Utils.getPaymentIcon(booking.payment_method)}"></i> Оплата</span>
                            <span class="info-value">${Utils.getPaymentText(booking.payment_method)}</span>
                        </div>
                    </div>
                    ${booking.status === 'approved' ? `
                        <div class="card-actions">
                            <button class="btn-review" onclick="Reviews.showReviewModal(${booking.id})">
                                <i class="fa-regular fa-comment"></i> Оставить отзыв
                            </button>
                        </div>
                    ` : ''}
                </div>
            </div>
        `).join('');

        container.querySelectorAll('.img-skeleton').forEach(img => {
            img.addEventListener('load', function() {
                this.classList.remove('img-skeleton');
            });
        });
    }
}

// Facilities Module
class Facilities {
    static async search(query) {
        try {
            const facilities = await Utils.apiRequest(`/facilities/search?name=${encodeURIComponent(query)}`);
            this.renderSuggestions(facilities);
        } catch (error) {
            console.error('Error searching facilities:', error);
        }
    }

    static renderSuggestions(facilities) {
        const suggestionsDiv = document.getElementById('facility-suggestions');
        
        if (facilities.length === 0) {
            suggestionsDiv.classList.remove('active');
            return;
        }

        suggestionsDiv.innerHTML = facilities.map(f => `
            <div class="suggestion-item" data-id="${f.id}" data-name="${f.name}">
                <div class="suggestion-image">
                    ${Utils.renderImage(f.image_url, f.name, 'suggestion-thumb')}
                </div>
                <div class="suggestion-info">
                    <div class="suggestion-title">${f.name}</div>
                    <div class="suggestion-type">
                        <i class="fa-solid fa-layer-group"></i> ${f.type}
                    </div>
                </div>
            </div>
        `).join('');

        suggestionsDiv.classList.add('active');

        suggestionsDiv.querySelectorAll('.suggestion-item').forEach(item => {
            item.addEventListener('click', () => {
                document.getElementById('facility-search').value = item.dataset.name;
                document.getElementById('facility-id').value = item.dataset.id;
                suggestionsDiv.classList.remove('active');
            });
        });

        suggestionsDiv.querySelectorAll('.img-skeleton').forEach(img => {
            img.addEventListener('load', function() {
                this.classList.remove('img-skeleton');
            });
        });
    }
}

// Reviews Module
class Reviews {
    static async loadUserReviews() {
        try {
            const reviews = await Utils.apiRequest('/reviews/my');
            this.renderReviews(reviews);
        } catch (error) {
            console.error('Error loading reviews:', error);
        }
    }

    static showReviewModal(bookingId) {
        state.selectedBookingId = bookingId;
        document.getElementById('review-modal').classList.add('active');
    }

    static hideReviewModal() {
        document.getElementById('review-modal').classList.remove('active');
        document.getElementById('review-form').reset();
        state.selectedBookingId = null;
    }

    static async submitReview(rating, comment) {
        try {
            await Utils.apiRequest('/reviews', {
                method: 'POST',
                body: JSON.stringify({
                    booking_id: state.selectedBookingId,
                    rating: parseInt(rating),
                    comment: comment
                })
            });

            alert('Отзыв успешно добавлен!');
            this.hideReviewModal();
            this.loadUserReviews();
        } catch (error) {
            alert(error.message);
        }
    }

    static renderReviews(reviews) {
        const container = document.getElementById('reviews-list');
        
        if (reviews.length === 0) {
            container.innerHTML = `
                <div class="card empty-state">
                    <div class="empty-icon"><i class="fa-regular fa-comments"></i></div>
                    <p>Отзывов пока нет</p>
                    <span>Оставьте отзыв после прохождения тренировки</span>
                </div>`;
            return;
        }

        container.innerHTML = reviews.map(review => `
            <div class="card review-card">
                <div class="review-image">
                    ${Utils.renderImage(review.facility_image, review.facility_name)}
                </div>
                <div class="review-content">
                    <div class="review-header">
                        <div class="card-title">${review.facility_name}</div>
                        ${Utils.renderStars(review.rating)}
                    </div>
                    <div class="review-meta">
                        <i class="fa-regular fa-calendar"></i> ${Utils.formatDate(review.booking_date)}
                    </div>
                    ${review.comment ? `<div class="card-body"><p class="review-comment">${review.comment}</p></div>` : ''}
                </div>
            </div>
        `).join('');

        container.querySelectorAll('.img-skeleton').forEach(img => {
            img.addEventListener('load', function() {
                this.classList.remove('img-skeleton');
            });
        });
    }
}

// Admin Module
class Admin {
    static async loadAllBookings() {
        try {
            const bookings = await Utils.apiRequest('/bookings/all');
            this.renderAdminBookings(bookings);
        } catch (error) {
            console.error('Error loading admin bookings:', error);
        }
    }

    static async updateStatus(bookingId, status) {
        try {
            await Utils.apiRequest(`/bookings/${bookingId}/status`, {
                method: 'PATCH',
                body: JSON.stringify({ status })
            });

            alert(`Заявка ${status === 'approved' ? 'одобрена' : 'отклонена'}`);
            this.loadAllBookings();
        } catch (error) {
            alert(error.message);
        }
    }

    static renderAdminBookings(bookings) {
        const container = document.getElementById('admin-bookings-list');
        
        if (bookings.length === 0) {
            container.innerHTML = `
                <div class="card empty-state">
                    <div class="empty-icon"><i class="fa-regular fa-inbox"></i></div>
                    <p>Заявок нет</p>
                    <span>Все заявки обработаны</span>
                </div>`;
            return;
        }

        container.innerHTML = bookings.map(booking => `
            <div class="card booking-card">
                <div class="booking-image">
                    ${Utils.renderImage(booking.facility_image, booking.facility_name)}
                    <span class="status-badge status-${booking.status}">
                        <i class="fa-solid ${booking.status === 'approved' ? 'fa-circle-check' : booking.status === 'rejected' ? 'fa-circle-xmark' : 'fa-clock'}"></i>
                        ${Utils.getStatusText(booking.status)}
                    </span>
                </div>
                <div class="booking-content">
                    <div class="booking-header">
                        <div class="booking-title-block">
                            <div class="card-title">${booking.facility_name}</div>
                            <div class="card-subtitle">
                                <i class="fa-solid fa-user"></i> ${booking.user_name} <span class="muted">(${booking.user_login})</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-info">
                        <div class="info-item">
                            <span class="info-label"><i class="fa-regular fa-calendar"></i> Дата</span>
                            <span class="info-value">${Utils.formatDate(booking.booking_date)}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label"><i class="fa-solid ${Utils.getPaymentIcon(booking.payment_method)}"></i> Оплата</span>
                            <span class="info-value">${Utils.getPaymentText(booking.payment_method)}</span>
                        </div>
                    </div>
                    ${booking.status === 'pending' ? `
                        <div class="card-actions">
                            <button class="btn-approve" onclick="Admin.updateStatus(${booking.id}, 'approved')">
                                <i class="fa-solid fa-circle-check"></i> Одобрить
                            </button>
                            <button class="btn-reject" onclick="Admin.updateStatus(${booking.id}, 'rejected')">
                                <i class="fa-solid fa-circle-xmark"></i> Отклонить
                            </button>
                        </div>
                    ` : ''}
                </div>
            </div>
        `).join('');

        container.querySelectorAll('.img-skeleton').forEach(img => {
            img.addEventListener('load', function() {
                this.classList.remove('img-skeleton');
            });
        });
    }
}

// App Controller
class App {
    static init() {
        if (state.token && state.user) {
            this.showAppScreen();
        } else {
            this.showAuthScreen();
        }

        this.bindEvents();
    }

    static bindEvents() {
        document.getElementById('login-btn').addEventListener('click', () => {
            const login = document.getElementById('login-input').value;
            const password = document.getElementById('password-input').value;
            Auth.login(login, password);
        });

        document.getElementById('password-input').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('login-btn').click();
            }
        });

        document.getElementById('register-btn').addEventListener('click', () => {
            const userData = {
                login: document.getElementById('reg-login').value,
                password: document.getElementById('reg-password').value,
                full_name: document.getElementById('reg-fullname').value,
                phone: document.getElementById('reg-phone').value,
                email: document.getElementById('reg-email').value
            };
            Auth.register(userData);
        });

        document.getElementById('reg-email').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('register-btn').click();
            }
        });

        document.getElementById('show-register').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('login-form').classList.remove('active');
            document.getElementById('register-form').classList.add('active');
        });

        document.getElementById('show-login').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('register-form').classList.remove('active');
            document.getElementById('login-form').classList.add('active');
        });

        document.getElementById('logout-btn').addEventListener('click', () => {
            Auth.logout();
        });

        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const page = btn.dataset.page;
                this.navigateTo(page);
            });
        });

        document.getElementById('booking-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const facilityName = document.getElementById('facility-search').value;
            const bookingDate = document.getElementById('booking-date').value;
            const paymentMethod = document.getElementById('payment-method').value;

            if (!facilityName || !bookingDate || !paymentMethod) {
                alert('Заполните все поля');
                return;
            }

            Bookings.createBooking(facilityName, bookingDate, paymentMethod);
        });

        let searchTimeout;
        document.getElementById('facility-search').addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            const value = e.target.value;
            if (value.trim().length === 0) {
                document.getElementById('facility-suggestions').classList.remove('active');
                return;
            }
            searchTimeout = setTimeout(() => {
                Facilities.search(value);
            }, 300);
        });

        document.getElementById('cancel-review').addEventListener('click', () => {
            Reviews.hideReviewModal();
        });

        document.getElementById('review-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const rating = document.getElementById('review-rating').value;
            const comment = document.getElementById('review-comment').value;
            Reviews.submitReview(rating, comment);
        });

        document.addEventListener('click', (e) => {
            const suggestionsDiv = document.getElementById('facility-suggestions');
            const facilitySearch = document.getElementById('facility-search');
            if (suggestionsDiv && !suggestionsDiv.contains(e.target) && e.target !== facilitySearch) {
                suggestionsDiv.classList.remove('active');
            }
        });

        document.getElementById('review-modal').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                Reviews.hideReviewModal();
            }
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const modal = document.getElementById('review-modal');
                if (modal.classList.contains('active')) {
                    Reviews.hideReviewModal();
                }
                const suggestionsDiv = document.getElementById('facility-suggestions');
                if (suggestionsDiv.classList.contains('active')) {
                    suggestionsDiv.classList.remove('active');
                }
            }
        });
    }

    static navigateTo(page) {
        state.currentPage = page;

        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.page === page);
        });

        document.querySelectorAll('.page').forEach(p => {
            p.classList.remove('active');
        });
        document.getElementById(`${page}-page`).classList.add('active');

        if (page === 'bookings') {
            Bookings.loadUserBookings();
        } else if (page === 'reviews') {
            Reviews.loadUserReviews();
        } else if (page === 'admin') {
            Admin.loadAllBookings();
        }
    }

    static showAuthScreen() {
        document.getElementById('auth-screen').classList.add('active');
        document.getElementById('app-screen').classList.remove('active');
    }

    static showAppScreen() {
        document.getElementById('auth-screen').classList.remove('active');
        document.getElementById('app-screen').classList.add('active');

        document.getElementById('user-name').textContent = state.user.full_name;

        if (state.user.role === 'admin') {
            document.querySelectorAll('.admin-only').forEach(el => {
                el.classList.add('visible');
            });
        }

        this.navigateTo('bookings');
    }
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
