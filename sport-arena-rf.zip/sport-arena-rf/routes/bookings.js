const express = require('express');
const router = express.Router();
const BookingController = require('../controllers/bookingController');
const AuthMiddleware = require('../middleware/auth');

router.post('/', AuthMiddleware.authenticate, BookingController.create);
router.get('/my', AuthMiddleware.authenticate, BookingController.getUserBookings);
router.get('/all', AuthMiddleware.authenticate, AuthMiddleware.authorizeAdmin, BookingController.getAllBookings);
router.patch('/:id/status', AuthMiddleware.authenticate, AuthMiddleware.authorizeAdmin, BookingController.updateStatus);

module.exports = router;