const express = require('express');
const router = express.Router();
const FacilityController = require('../controllers/facilityController');
const AuthMiddleware = require('../middleware/auth');

router.get('/', AuthMiddleware.authenticate, FacilityController.getAll);
router.get('/search', AuthMiddleware.authenticate, FacilityController.search);

module.exports = router;