const express = require('express');
const router = express.Router();
const ReviewController = require('../controllers/reviewController');
const AuthMiddleware = require('../middleware/auth');

router.post('/', AuthMiddleware.authenticate, ReviewController.create);
router.get('/my', AuthMiddleware.authenticate, ReviewController.getUserReviews);

module.exports = router;