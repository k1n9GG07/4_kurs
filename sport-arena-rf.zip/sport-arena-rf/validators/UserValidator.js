class UserValidator {
    static validateLogin(login) {
        const regex = /^[a-zA-Z0-9]{6,}$/;
        if (!regex.test(login)) {
            return { valid: false, message: 'Логин должен содержать только латиницу и цифры, минимум 6 символов' };
        }
        return { valid: true };
    }

    static validatePassword(password) {
        if (password.length < 8) {
            return { valid: false, message: 'Пароль должен содержать минимум 8 символов' };
        }
        return { valid: true };
    }

    static validateFullName(fullName) {
        const regex = /^[а-яА-ЯёЁ\s]+$/;
        if (!regex.test(fullName)) {
            return { valid: false, message: 'ФИО должно содержать только кириллицу и пробелы' };
        }
        return { valid: true };
    }

    static validatePhone(phone) {
        const regex = /^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/;
        if (!regex.test(phone)) {
            return { valid: false, message: 'Телефон должен быть в формате 8(XXX)XXX-XX-XX' };
        }
        return { valid: true };
    }

    static validateEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regex.test(email)) {
            return { valid: false, message: 'Некорректный формат электронной почты' };
        }
        return { valid: true };
    }

    static validateRegistration(data) {
        const errors = [];

        const loginCheck = this.validateLogin(data.login);
        if (!loginCheck.valid) errors.push(loginCheck.message);

        const passwordCheck = this.validatePassword(data.password);
        if (!passwordCheck.valid) errors.push(passwordCheck.message);

        const fullNameCheck = this.validateFullName(data.full_name);
        if (!fullNameCheck.valid) errors.push(fullNameCheck.message);

        const phoneCheck = this.validatePhone(data.phone);
        if (!phoneCheck.valid) errors.push(phoneCheck.message);

        const emailCheck = this.validateEmail(data.email);
        if (!emailCheck.valid) errors.push(emailCheck.message);

        return {
            valid: errors.length === 0,
            errors: errors
        };
    }
}

module.exports = UserValidator;